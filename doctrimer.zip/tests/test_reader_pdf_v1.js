// Запуск: node tests/test_reader_pdf_v1.js ./path/to/file.pdf
import { Ollama } from 'ollama';
import { config } from '../src/core/config.js';
import { processSingleFile } from '../src/pipeline/process_file.js';

const args = process.argv.slice(2);
if (!args[0]) {
  console.error('Укажи путь к PDF: node tests/test_reader_pdf_v1.js ./samples/doc.pdf');
  process.exit(2);
}
const pdfPath = args[0];
const host = process.env.OLLAMA_HOST || config.ollamaHost;

async function main() {
  try {
    const r = await fetch(`${host}/api/version`);
    if (!r.ok) throw new Error('Ollama /api/version недоступен');
    const v = await r.json();
    console.log('[ok] Ollama version:', v.version);
  } catch (e) {
    console.error('Не могу достучаться до Ollama.', e.message);
  }

  const out = await processSingleFile(pdfPath);
  console.log('=== PDF REPORT JSON ===\n', JSON.stringify(out, null, 2));
}

main().catch(e => {
  console.error('Ошибка в test_reader_pdf_v1:', e);
  process.exit(1);
});
