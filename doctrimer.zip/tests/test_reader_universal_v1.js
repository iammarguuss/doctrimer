// Запуск:
//   node tests/test_reader_universal_v1.js ./samples/pm1.jpg
//   node tests/test_reader_universal_v1.js ./samples/pm2.pdf
import { config } from '../src/core/config.js';
import { processSingleFile } from '../src/pipeline/process_file.js';

const args = process.argv.slice(2);
if (!args[0]) {
  console.error('Укажи путь к файлу (pdf/jpg/png/webp): node tests/test_reader_universal_v1.js ./samples/file');
  process.exit(2);
}
const filePath = args[0];

async function main() {
  // Проверим Ollama
  try {
    const r = await fetch(`${config.ollamaHost}/api/version`);
    if (!r.ok) throw new Error('Ollama /api/version недоступен');
    const v = await r.json();
    console.log('[ok] Ollama version:', v.version);
  } catch (e) {
    console.warn('[warn] Не удалось проверить Ollama:', e.message);
  }

  const result = await processSingleFile(filePath);
  console.log('=== UNIVERSAL REPORT JSON ===\n', JSON.stringify(result, null, 2));
}

main().catch(e => {
  console.error('Ошибка в универсальном тесте:', e);
  process.exit(1);
});
