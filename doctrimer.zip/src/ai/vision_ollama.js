import { Ollama } from 'ollama';
import fs from 'node:fs/promises';
import { config } from '../core/config.js';
import { docSchema } from '../schema/doc_schema.js';
import { reportSchema } from '../schema/report_schema.js';

const ollama = new Ollama({ host: config.ollamaHost });

export async function ensureVisionModel() {
  const { models } = await ollama.list();
  const present = models.some(m => m.name === config.visionModel);
  if (!present) {
    throw new Error(
      `Модель ${config.visionModel} не найдена локально. Выполни:\n` +
      `  ollama pull ${config.visionModel}\n` +
      `И убедись, что сервис Ollama запущен (${config.ollamaHost}).`
    );
  }
}

const normStr = v => (v ?? '').toString().trim().replace(/\s+/g, ' ');
function majorityVote(values) {
  const arr = values.map(normStr).filter(Boolean);
  const counts = new Map();
  for (const v of arr) counts.set(v, (counts.get(v) || 0) + 1);
  let best = '', bestN = 0;
  for (const [k, n] of counts.entries()) {
    if (n > bestN || (n === bestN && k.length > best.length)) { best = k; bestN = n; }
  }
  return best || (values.find(Boolean) ?? '');
}
function mergeTexts(texts) {
  const seen = new Set(); const out = [];
  for (const t of texts) {
    const lines = String(t || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    for (const ln of lines) {
      const key = ln.toLowerCase();
      if (!seen.has(key)) { seen.add(key); out.push(ln); }
    }
  }
  return out.join('\n');
}
function normalizeEntitiesFromRun(run) {
  if (run && typeof run === 'object') {
    if (run.entities && typeof run.entities === 'object') return run.entities;
    if (run.key_fields && typeof run.key_fields === 'object') return run.key_fields;
    if (run.fields && typeof run.fields === 'object') return run.fields;
  }
  return {};
}

/** Один проход по изображению */
export async function classifyFromImage(imagePath) {
  const img = await fs.readFile(imagePath);
  const b64 = img.toString('base64');

  const system = [
    'Ты — извлекатель структурированной информации из сканов/фото документов.',
    'СТРОГО соблюдай схему: doc_type, language, confidence, summary, extracted_text, entities (все поля обязательны).',
    'ВСЕ извлечённые ключи клади ВНУТРИ "entities". Запрещены top-level "fields"/"key_fields".',
    'В "extracted_text" верни как можно больше распознанного текста (строки с переносами).',
    'Только JSON.'
  ].join(' ');

  const resp = await ollama.chat({
    model: config.visionModel,
    stream: false,
    format: docSchema, // structured output
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: 'Определи тип, дай summary, текст и entities. Верни ТОЛЬКО JSON.', images: [b64] }
    ],
    options: { temperature: 0 } // максимально детерминированно
  });

  const raw = resp?.message?.content?.trim() || '{}';
  let parsed;
  try { parsed = JSON.parse(raw); }
  catch {
    // fallback — хотя бы пустые обязательные поля
    parsed = { doc_type: 'unknown', confidence: 0, language: '', summary: '', extracted_text: '', entities: {}, raw };
  }
  // нормализация возможных отклонений
  parsed.entities = normalizeEntitiesFromRun(parsed);
  parsed.summary = parsed.summary ?? '';
  parsed.extracted_text = parsed.extracted_text ?? '';
  parsed.language = parsed.language ?? '';
  return { version: '1.0', ...parsed };
}

/** Мультипроход (по умолчанию 3) */
export async function classifyImageMultiple(imagePath, passes = 3) {
  const runs = [];
  for (let i = 0; i < passes; i++) runs.push(await classifyFromImage(imagePath));
  const aggregated = aggregateRuns(runs);
  return { runs, aggregated };
}

/** Агрегация нескольких прогонов */
export function aggregateRuns(runs) {
  const docTypes = runs.map(r => r.doc_type).filter(Boolean);
  const languages = runs.map(r => r.language).filter(Boolean);
  const confidences = runs.map(r => Number(r.confidence) || 0);
  const texts = runs.map(r => r.extracted_text || '');
  const summaries = runs.map(r => r.summary || '');

  const allKeys = new Set();
  for (const r of runs) {
    const ent = normalizeEntitiesFromRun(r);
    Object.keys(ent).forEach(k => allKeys.add(k));
  }
  const entities = {};
  for (const key of allKeys) {
    const vals = runs.map(r => normalizeEntitiesFromRun(r)[key]).filter(Boolean);
    if (vals.length) entities[key] = majorityVote(vals);
  }

  return {
    version: '1.0',
    doc_type: majorityVote(docTypes) || 'unknown',
    language: majorityVote(languages) || '',
    confidence: confidences.length ? Number((confidences.reduce((a,b)=>a+b,0) / confidences.length).toFixed(3)) : 0,
    summary: majorityVote(summaries),
    extracted_text: mergeTexts(texts),
    entities
  };
}

/** Финальный отчёт по изображению + агрегату */
export async function buildStructuredReport(imagePath, aggregated) {
  const img = await fs.readFile(imagePath);
  const b64 = img.toString('base64');

  const system = [
    'Ты — аналитик документов.',
    'Вход: изображение и агрегированные извлечения (включая entities/extracted_text).',
    'Верни ТОЛЬКО JSON по reportSchema (summary, key_points, important_fields, entities, index_terms, tags).'
  ].join(' ');

  const userContent = [
    'Агрегированные извлечения:',
    JSON.stringify(aggregated, null, 2),
    'Верни ТОЛЬКО JSON отчёта.'
  ].join('\n');

  const resp = await ollama.chat({
    model: config.visionModel,
    stream: false,
    format: reportSchema,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: userContent, images: [b64] }
    ],
    options: { temperature: 0 }
  });

  const raw = resp?.message?.content?.trim() || '{}';
  try { return JSON.parse(raw); }
  catch { return { version: '1.0', doc_type: aggregated.doc_type || 'unknown', summary: '', entities: {}, raw }; }
}
