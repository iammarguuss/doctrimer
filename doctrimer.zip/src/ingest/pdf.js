import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';

// pdf-parse — CJS. Подключаем надёжно в ESM:
const require = createRequire(import.meta.url);
const pdfParse = require('pdf-parse');

export async function extractTextFromPdf(pdfPath) {
  const dataBuffer = await fs.readFile(pdfPath);
  const data = await pdfParse(dataBuffer);
  return {
    text: data.text || '',
    pageCount: typeof data.numpages === 'number' ? data.numpages : undefined,
    info: data.info || {}
  };
}

function getPdftoppmCmd() {
  if (process.env.PDFTOPPM_PATH) return process.env.PDFTOPPM_PATH;
  return process.platform === 'win32' ? 'pdftoppm.exe' : 'pdftoppm';
}

export function pdftoppmAvailable() {
  const cmd = getPdftoppmCmd();
  const res = spawnSync(cmd, ['-v'], { shell: true, stdio: 'ignore' });
  return res.status === 0;
}

/**
 * Конвертация первых pagesLimit страниц PDF → PNG (Poppler: pdftoppm).
 * outDir — куда складывать PNG (будет создана).
 */
export async function rasterizePdfToPngs(pdfPath, outDir, pagesLimit = 2, dpi = 200) {
  await fs.mkdir(outDir, { recursive: true });
  const baseName = path.basename(pdfPath, path.extname(pdfPath)).replace(/\s+/g, '_');
  const prefix = path.join(outDir, baseName);

  const args = ['-png', '-r', String(dpi), '-f', '1', '-l', String(pagesLimit), pdfPath, prefix];
  const cmd = getPdftoppmCmd();
  const res = spawnSync(cmd, args, { shell: true, stdio: 'inherit' });
  if (res.status !== 0) return [];

  const out = [];
  for (let i = 1; i <= pagesLimit; i++) {
    const f = `${prefix}-${i}.png`;
    try { await fs.access(f); out.push(f); } catch {}
  }
  return out;
}
