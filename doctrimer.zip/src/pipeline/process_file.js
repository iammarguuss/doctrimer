import path from 'node:path';
import { classifyImageMultiple, buildStructuredReport, aggregateRuns } from '../ai/vision_ollama.js';
import { rasterizePdfToPngs, pdftoppmAvailable, extractTextFromPdf } from '../ingest/pdf.js';
import { embedText, ensureEmbedModel } from '../ai/embed_ollama.js';

// служебка
const normStr = v => (v ?? '').toString().trim().replace(/\s+/g, ' ');

function mergeAggregatedMany(aggs) {
  if (!aggs.length) {
    return { version: '1.0', doc_type: 'unknown', language: '', confidence: 0, summary: '', extracted_text: '', entities: {} };
  }
  // Сведём как если бы это были "прогоны" разных страниц
  const fakeRuns = aggs.map(a => ({
    doc_type: a.doc_type,
    language: a.language,
    confidence: a.confidence,
    summary: a.summary,
    extracted_text: a.extracted_text,
    entities: a.entities
  }));
  return aggregateRuns(fakeRuns);
}

function buildIndexText(summary, text, entities) {
  return [summary || '', text || '', JSON.stringify(entities || {}, null, 0)].join('\n');
}

/** 3-проходная обработка одиночного изображения */
async function processImageFile(imagePath) {
  const { runs, aggregated } = await classifyImageMultiple(imagePath, 3);
  const report = await buildStructuredReport(imagePath, aggregated);

  try { await ensureEmbedModel(); } catch {}
  const { vector, dim } = await embedText(buildIndexText(aggregated.summary, aggregated.extracted_text, aggregated.entities))
    .catch(() => ({ vector: [], dim: 0 }));

  return {
    source: { kind: 'image', path: imagePath },
    meta: { passes: 3 },
    ensemble: { runs, vote: aggregated },
    report,
    text_dump: aggregated.extracted_text,
    embedding: { model: process.env.EMBED_MODEL || 'all-minilm', dim, vector }
  };
}

/** 3-проходная обработка PDF (растеризация первых страниц → VLM) */
async function processPdfFile(pdfPath) {
  const tmpOut = 'data/tmp/pdf_pages';
  const limit = Number(process.env.PDF_PAGES_LIMIT || 2);

  if (!pdftoppmAvailable()) {
    // Попытаемся хотя бы текст вытащить, чтобы не падать
    const { text, pageCount } = await extractTextFromPdf(pdfPath).catch(() => ({ text: '', pageCount: undefined }));
    const hint = [
      'pdftoppm (Poppler) не найден.',
      'Для визуального анализа PDF установи Poppler и пропиши PDFTOPPM_PATH в .env.'
    ].join(' ');
    return {
      source: { kind: 'pdf', path: pdfPath, pageCount },
      error: hint,
      report: { version: '1.0', doc_type: 'document', summary: '', entities: {}, key_points: [], important_fields: [], index_terms: [], tags: [] },
      text_dump: text || ''
    };
  }

  const pages = await rasterizePdfToPngs(pdfPath, tmpOut, limit, 200);
  if (!pages.length) {
    return {
      source: { kind: 'pdf', path: pdfPath },
      error: 'Не удалось растеризовать PDF в изображения. Проверь pdftoppm и права на запись в data/tmp.',
    };
  }

  // 3-проходная обработка по (первым) страницам
  const perPageAgg = [];
  for (const img of pages) {
    const { aggregated } = await classifyImageMultiple(img, 3);
    perPageAgg.push(aggregated);
  }
  const merged = mergeAggregatedMany(perPageAgg);
  const firstImage = pages[0];
  const report = await buildStructuredReport(firstImage, merged);

  // эмбеддинг
  try { await ensureEmbedModel(); } catch {}
  const { vector, dim } = await embedText(buildIndexText(merged.summary, merged.extracted_text, merged.entities))
    .catch(() => ({ vector: [], dim: 0 }));

  return {
    source: { kind: 'pdf', path: pdfPath, pages: pages.slice() },
    meta: { passes_per_page: 3, pages_used: pages.length },
    ensemble: { per_page: perPageAgg, vote: merged },
    report,
    text_dump: merged.extracted_text,
    embedding: { model: process.env.EMBED_MODEL || 'all-minilm', dim, vector }
  };
}

/** Универсальная точка входа */
export async function processSingleFile(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) return processImageFile(filePath);
  if (ext === '.pdf') return processPdfFile(filePath);
  return { source: { kind: 'unknown', path: filePath }, error: 'Unsupported file type (only images/pdf are supported)' };
}
